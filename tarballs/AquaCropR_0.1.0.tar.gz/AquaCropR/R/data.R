#' Example data for running AquaCrop from R
#'
#' @format ## `Quinoa`
#' is a loaded list of Quinoa parameters, reproducing the result of the `read_CRO` function applied to the Quinoa.CRO file.
#'
